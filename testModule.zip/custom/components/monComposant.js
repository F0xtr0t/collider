export default function() {
    const setup=()=>{

    }



    return {
        setup
    }
}
import { components } from './modules/components.js';

document.addEventListener("DOMContentLoaded",() => {
    components().createAllComponents(document);
});

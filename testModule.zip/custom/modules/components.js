export const components = () => {
    const attrName = 'data-nqis';
    function createAllComponents(fromNode) {
        var compos = fromNode.querySelectorAll('[' + attrName + ']');
        if(compos) {
            compos.forEach(c => {
                import('./../components/'+c.getAttribute(attrName)+'.js')
                    .then((compo) => {
                        console.log("test");
                    });
            });
        }
    }

    return {
        createAllComponents
    }
}



